import 'package:flutter/material.dart';


class CoffeTile extends StatelessWidget {

  final String coffeImagePath;
  final String coffeName;
  final String coffePrice;

  const CoffeTile({super.key, required this.coffeImagePath, required this.coffeName, required this.coffePrice});
  

  @override
  Widget build(BuildContext context) {
    return Padding(
         padding: const EdgeInsets.only(left: 25.0 , bottom: 2),
         child: Container(
          padding: EdgeInsets.all(12),
         width: 200,
         decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: Colors.black54,
         ),
         child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.asset(
                coffeImagePath,
                height: 130,
                width: 130,
                fit: BoxFit.cover,
                )
            ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical : 12.0, horizontal: 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
              Text(
                coffeName,
                style: TextStyle(fontSize: 20),
                ),
              Text(
                'With Almond Milk',
                style: TextStyle(color: Colors.grey[400]),
              ),
              ],
            ),
          ),
          //Price
          Padding(
            padding: const EdgeInsets.symmetric( horizontal: 25.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('\$' + coffePrice),
                Container(
                  decoration: BoxDecoration(
                    color: Colors.orange,
                    borderRadius: BorderRadius.circular(6)
                  ),
                  child: Icon(Icons.add),
                )
              ],
            ),
          )
          ]
         ),
        )
       );
  }
}